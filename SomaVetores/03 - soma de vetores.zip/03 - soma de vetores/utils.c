#include <stdio.h>


void print_array_int(int*array, int tamanho)
{
  for (int i =0;i<tamanho;i++)
  {
     printf("%d\n",array[i]);
  }
}
